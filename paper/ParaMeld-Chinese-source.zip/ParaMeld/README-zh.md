# ParaMeld中文论文

正文、参考文献与六项附录共同编译在一份PDF中，入口为`main.tex`。附录包含完整训练配置、真实Agent策略轨迹、Lightning配对核查、预测搜索的候选来源、执行证据对照，以及历史并行配置和原图。

采用单栏Letter排版，拉丁字体为Libertine，中文为宋体；正文10磅，标题20.74磅，表题与图题居中。引用采用已核查的29项学术条目。原九模型主表和组件消融保留归档数值，原有图片保持文件内容。

编译需要Tectonic或XeLaTeX，以及CTeX、Libertine、newtxmath、natbib、algorithm和algpseudocode等依赖。中文字体采用macOS系统宋体，字体文件由本地环境提供。

解压并进入`ParaMeld`目录后，执行：

```sh
tectonic main.tex
```

四模型FP16计算与FP32优化器状态的配对记录分别保存每项策略的一次完整测量。附录中的Qwen3-14B训练轨迹区分分区工具、Agent联合修改与相同策略复测。Nemotron预测轨迹区分一次模型调用产生的调查与数值工具的后续展开。Lightning同条件布局记录的吞吐提升为14.42%。
